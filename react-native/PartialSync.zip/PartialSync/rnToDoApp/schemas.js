export const taskSchema = {
    name: 'task',
    properties: {
        taskID: 'string',
        owner: 'string',
        name: 'string',
    }
}